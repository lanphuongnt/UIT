#include <stdio.h>

int main(){
	int a[1];
	printf("%d", a[-896671785]);
	return 0;
}

