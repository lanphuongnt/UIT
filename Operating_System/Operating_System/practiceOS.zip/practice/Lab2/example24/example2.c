#include <stdio>

int func(int a, int b){
	return a + b;
}


void main(){
	printf("%d", func(2, 3));
}
