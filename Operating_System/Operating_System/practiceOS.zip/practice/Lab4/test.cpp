#include<iostream>
using namespace std;
int main(){
    int x = 0;
    int n = 3;
    int sum = 0;
    do{
        x++;
        sum+=x;
    }while(x<=n);
    cout << sum;
}