
#include <iostream>
#include <queue>
#include <string>
#include <algorithm>
#include <vector>

using namespace std;

struct Process{
    string name;
    int index;
    int arrival_time;
    int burst_time;

    bool operator<(const Process& p) const{
        return burst_time < p.burst_time;
    }
    bool operator>(const Process& p) const{
        return burst_time > p.burst_time;
    }
};

bool compare_arrival_time(Process p1, Process p2){
    return p1.arrival_time < p2.arrival_time;
}

/**
 * Tính thời gian đáp ứng trung bình
*/
int calculate_response_time(vector< pair<int, int> > active_time_of_process[], Process process){
    return active_time_of_process[process.index][0].first - process.arrival_time;
}
/**
 * Tính thời gian đợi trung bình
*/
int calculate_waiting_time(vector< pair<int, int> > active_time_of_process[], Process process){
    int result = calculate_response_time(active_time_of_process, process);
    for(int i = 1; i < active_time_of_process[process.index].size(); i++){
        result += active_time_of_process[process.index][i].first - active_time_of_process[process.index][i - 1].second;
    }
    return result;
}

/**
 * Tính thời gian hoàn thành trung bình6
*/
double calculate_turnaround_time(vector< pair<int, int> > active_time_of_process[], Process process){
    return active_time_of_process[process.index][active_time_of_process[process.index].size() - 1].second - process.arrival_time;
}

int main(){
    int num_processes;
    double average_waiting_time = 0; // Thời gian đợi trung bình
    double average_turnaround_time = 0; // Thời gian hoàn thành trung bình
    double average_response_time = 0; // Thời gian phản hồi trung bình


    priority_queue<Process, vector<Process>, greater<Process>> pq; // Khai báo hàng đợi ưu tiên
    cout << "Enter the number of processes: ";
    cin >> num_processes; // Nhập input
    if (num_processes <= 0){
        cout << "Invalid number of processes" << endl;
        return 1;
    }
    
    Process list_processes[num_processes];
    vector< pair<int, int> > active_time_of_process[num_processes];
    // Nhập input
    cout << "Enter the name, arrival time and burst time of processes: (e.g: P1 0 5)" << endl;
    for(int i = 0; i < num_processes; i++){
        cout << ">> ";
        cin >> list_processes[i].name >> list_processes[i].arrival_time >> list_processes[i].burst_time;
        list_processes[i].index = i;
    }
    // Sắp xếp danh sách process
    sort(list_processes, list_processes + num_processes, compare_arrival_time);
    // Khởi tạo
    int current_time = 0;
    int count = num_processes;
    int index = 0;
    while (count){
        // Đẩy tiến trình đã tới vào hàng đợi
        while (list_processes[index].arrival_time <= current_time && index < num_processes){
            pq.push(list_processes[index]);
            index++;
        }
        if (!pq.empty()){
            // Lấy tiến trình được ưu tiên (có brust time nhỏ nhất)
            Process p = pq.top();
            pq.pop();
            cout << "Process " << p.name << " is running from " << current_time << " to " << current_time + p.burst_time << endl;
            // Lưu lại thời gian thực thi để tính toán thời gian đợi, hoàn thành và đáp ứng
            active_time_of_process[p.index].push_back(make_pair(current_time, current_time + p.burst_time));
            // Thời gian thực thi xong tiến trình
            current_time += p.burst_time;
            count--; // Tính số tiến trình còn lại
        }
        else {
            // Đưa thời gian lên tới lúc gặp tiến trình mới nếu không có tiến trình nào trong hàng đợi
            current_time = list_processes[index].arrival_time;
        }
    }
    // Tính toán thời gian trung bình
    for(int i = 0; i < num_processes; i++){
        average_waiting_time += calculate_waiting_time(active_time_of_process, list_processes[i]);
        average_turnaround_time += calculate_turnaround_time(active_time_of_process, list_processes[i]);
        average_response_time += calculate_response_time(active_time_of_process, list_processes[i]);
    }
    average_waiting_time /= num_processes;
    average_turnaround_time /= num_processes;
    average_response_time /= num_processes;

    cout << "Average waiting time: " << average_waiting_time << endl;
    cout << "Average turnaround time: " << average_turnaround_time << endl;
    cout << "Average response time: " << average_response_time << endl;
    return 0;
}

