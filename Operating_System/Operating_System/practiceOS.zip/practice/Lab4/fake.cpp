#include <iostream>
#include <cstring>
using namespace std;

char key[5] = {'F', 'A', '+', '+', '!'};
unsigned char sbox[256];

char *orkey(char *key, int len)
{
    for (int i = 1; i < len; ++i)
    {
        key[i] = key[i] | 1;
    }
    printf("Key : %s\n", key);
    return key;
}

unsigned char *create_sbox(unsigned char *sbox, int len)
{
    int k;   // [rsp+4h] [rbp-14h]
    char v7; // [rsp+Ch] [rbp-Ch]

    for (int i = 0; i < 256; ++i)
    {
        sbox[i] = i;
        cout << (unsigned int)sbox[i] << '\n';
    }
    k = 0;
    for (int j = 0; j < 256; ++j)
    {
        k = ((key[j % len]) + sbox[j] + k) % 256;
        v7 = sbox[j];
        sbox[j] = sbox[k];
        sbox[k] = v7;
    }
    return sbox;
}

void do_something_2(unsigned char *sbox, char *aStr, int len, char *string2)
{
    int v5;  // [rsp+0h] [rbp-28h]
    int i;   // [rsp+4h] [rbp-24h]
    int v7;  // [rsp+8h] [rbp-20h]
    char v8; // [rsp+Ch] [rbp-1Ch]

    v5 = 0;
    v7 = 0;
    for (i = 0; i < len; ++i)
    {
        v5 = (v5 + 1) % 256;
        v7 = ((unsigned __int8)sbox[v5] + v7) % 256;
        v8 = sbox[v5];
        sbox[v5] = sbox[v7];
        sbox[v7] = v8;
        string2[i] = sbox[((unsigned __int8)sbox[v7] + (unsigned __int8)sbox[v5]) % 256] ^ aStr[i];
    }
    string2[len] = 0;
}

void wth(char *fake_flag)
{
    char Str[128];
    char v5[128];
    Str[0] = 'f';
    Str[1] = 'M';
    Str[2] = 12;
    Str[3] = 0xA1;
    Str[4] = 86;
    Str[5] = 63;
    Str[6] = 43;
    Str[7] = 0xBD;
    Str[8] = 78;
    Str[9] = 97;
    Str[10] = 106;
    Str[11] = 0x8E;
    Str[12] = 73;
    Str[13] = 81;
    Str[14] = 61;
    Str[15] = 0x87;
    Str[16] = 114;
    Str[17] = 124;
    Str[18] = 54;
    Str[19] = 0x85;
    Str[20] = 69;
    Str[21] = 122;
    Str[22] = 104;
    Str[23] = 0xBD;
    Str[24] = 75;
    Str[25] = 98;
    Str[26] = 62;
    Str[27] = 0xDB;
    Str[28] = 114;
    Str[29] = 102;
    Str[30] = 58;
    Str[31] = 0x90;
    Str[32] = 72;
    Str[33] = 81;
    Str[34] = 1;
    Str[35] = 0xCC;
    Str[36] = 115;
    Str[37] = 78;
    Str[38] = 31;
    Str[39] = 0x9F;
    memset(&Str[40], 0, 0x58);
    memset(v5, 0, sizeof(v5));
    do_something_2(sbox, Str, 128, v5);

    // for (int i = 0; i < 128; ++i)
    //     v5[i] = fake_flag[i % 4] ^ Str[i];
    printf("OK: %s\n", v5);
}

int main()
{
    orkey(key, 4);
    printf("Key : %s\n", key);
    create_sbox(sbox, 5);
    // wth(key);
    for (int i = 0; i < 256; i++)
    {
        printf("%u ", sbox[i]);
        if (i % 8 == 7)
        {
            printf("\n");
        }
    }
    char aStr[1024];
    char string2[1024];
    aStr[0] = 0xDF;
    aStr[1] = 0x45;
    aStr[2] = 0x43;
    aStr[3] = 49;
    aStr[4] = 0x86;
    aStr[5] = 38;
    aStr[6] = 116;
    aStr[7] = 0x9F;
    aStr[8] = 0xA9;
    aStr[9] = 118;
    aStr[10] = 0x8D;
    aStr[11] = 0xAA;
    aStr[12] = 0x94;
    aStr[13] = 116;
    aStr[14] = 0xB7;
    aStr[15] = 46;
    aStr[16] = 0x9E;
    aStr[17] = 0xA2;
    aStr[18] = 20;
    aStr[19] = 5;
    aStr[20] = 109;
    aStr[21] = 0xA9;
    aStr[22] = 0xDE;
    aStr[23] = 0xA7;
    aStr[24] = 80;
    aStr[25] = 57;
    aStr[26] = 17;
    memset(&aStr[27], 0, 997);
    do_something_2(sbox, aStr, 1024, string2);
    printf("%s", string2);
    wth(string2);
    return 0;
}