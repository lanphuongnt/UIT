/*######################################
# University of Information Technology #
# IT007 Operating System #
# <Nguyen Tran Lan Phuong>, <22521168> #
# File: bai3.c #
######################################*/
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <signal.h>

void on_sigint(int sig)
{
    printf("\ncount.sh has stopped\n");
    kill(getpid(), sig);
    exit(0);
}

int main(int argc, char *argv[])
{
    signal(SIGINT, on_sigint);
    __pid_t pid;
    pid = fork();
    
    if (pid == 0)
    {
        execl("./count.sh", "./count.sh", "120", NULL);
    }
    else if (pid > 0)
    {
        printf("Welcome to IT007, I am 22521168\n");
        wait(NULL);
    }
    exit(0);
}
