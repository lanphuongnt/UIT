/*######################################
# University of Information Technology #
# IT007 Operating System #
# <Nguyen Tran Lan Phuong>, <22521168> #
# File: collatz.c #
######################################*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <sys/shm.h>
#include <sys/stat.h>
#include <unistd.h>
#include <sys/mman.h>
#include <time.h>
#include <sys/wait.h>
#include <signal.h>
#include <stdbool.h>
#include <string.h>

void calculate(int *shareBuffer, int n){
    int i = 0;
    shareBuffer[i] = n;
    while (n != 1){
        if (n & 1){
            n = 3 * n + 1;
        }
        else {
            n = n / 2;
        }
        shareBuffer[++i] = n;
    }
}

void display(int *shareBuffer){
    int i = 0;
    while (shareBuffer[i] != 0){
        printf("%d ", shareBuffer[i++]);
    }
    printf("\n");
}

bool checkInput(int n){
    if (n <= 0){
        return false;
    }
    return true;
}

int main(int argc, char *argv[])
{

    if (argc != 2){
        printf("Invalid input! Please enter a positive number\n");
        return 0;
    }
    int n = atoi(argv[1]);
    if (!checkInput(n)){
        printf("Invalid input! Please enter a positive number\n");
        return 0;
    }
    /* the size (in bytes) of shared memory object */
    const int SIZE = 4096;
    /* name of the shared memory object */
    const char *name = "COLLATZ";
    /* shared memory file descriptor */
    int fd;
    /* pointer to shared memory obect */
    int *ptr;
    /* create the shared memory object */
    fd = shm_open(name, O_CREAT | O_RDWR, 0666);
    /* configure the size of the shared memory object */
    ftruncate(fd, SIZE);
    /* memory map the shared memory object */
    ptr = mmap(0, SIZE, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
    /* write to the shared memory object */
    memset(ptr, 0, SIZE);
    pid_t pid;
    pid = fork();
    if (pid == 0){
        calculate(ptr, n);
    }
    if (pid > 0){
        wait(NULL); // wait for child process to finish
        display(ptr);
    }
    /* unmap the shared memory segment and close the file descriptor */
    munmap(ptr, SIZE);
    close(fd);
    return 0;
}