/*######################################
# University of Information Technology #
# IT007 Operating System #
# <Nguyen Tran Lan Phuong>, <22521168> #
# File: producer.c #
######################################*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <sys/shm.h>
#include <sys/stat.h>
#include <unistd.h>
#include <sys/mman.h>
#include <time.h>
#include <sys/wait.h>
#include <signal.h>
#include <stdbool.h>
#include <string.h>


char randomInRange(int min, int max){
    return min + rand() % (max + 1 - min);
}

void producer(char *ptr){    
    int i = 0;
    while (true){
        sleep(2);
        ptr[i] = (char) randomInRange(10, 20);
        printf("PRODUCER | Add %d to bounded-buffer\n", (char) ptr[i]);
        i++;
    }
}

int calSumAndDisplay(char *ptr, int len){
    int sum = 0;
    printf("CONSUMER | Bounded-buffer: ");
    for (int i = 0; i <= len; i++){
        sum += (char) *(ptr + i);
        printf("%d ", (char) *(ptr + i));
    }
    return sum;
}

void consumer(char *ptr){
    
    int sum = 0;
    int i = 0;
    while (true)
    {
        while ((char)*(ptr + i) == 0){
            printf("CONSUMER | Waiting Producer update data in bounded-buffer\n");
            sleep(1);
        }
        int sum = calSumAndDisplay(ptr, i);
        printf("\nCONSUMER | Sum of bounded-buffer: %d\n", sum);
        i++;
        sleep(1);
        if (sum > 100){
            printf("CONSUMER | Sum of bounded-buffer is greater than 100!\n");
            kill(getppid(), SIGTERM);
            break;
        }
    }
}

int main()
{
    pid_t pid;
    srand(time(NULL));
    const int SIZE = 10;
    /* name of the shared memory object */
    const char *name = "STORAGE";
    int fd;
    char *ptr;
    fd = shm_open(name, O_CREAT | O_RDWR, 0666);
    ftruncate(fd, SIZE);
    ptr = mmap(0, SIZE, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
    memset(ptr, 0, SIZE);

    pid = fork();
    if (pid == 0){
        consumer(ptr);
    }
    if (pid > 0){
        producer(ptr);
        wait(NULL);
    }
    munmap(ptr, SIZE);
    close(fd);
    printf("End of program!\n");
    exit(0);
}