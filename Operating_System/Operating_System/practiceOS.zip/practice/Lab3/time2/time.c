/*######################################
# University of Information Technology #
# IT007 Operating System #
# <Nguyen Tran Lan Phuong>, <22521168> #
# File: time.c #
######################################*/
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <sys/types.h>
int main(int argc, char *argv[])
{
    __pid_t pid;
    struct timeval start, end;
    pid = fork();
    gettimeofday(&start, NULL);
    if (pid == 0)
    {
        execl("/bin/sh", "sh", "-c", argv[1], NULL);
    }
    else if (pid > 0)
    {
        wait(NULL);
        gettimeofday(&end, NULL);
        double elapsedTime =(end.tv_sec - start.tv_sec) * 1000 + (end.tv_usec - start.tv_usec) / 1000.0;
        printf("Thời gian thực thi: %.5f ms\n", elapsedTime);    
    }
    exit(0);
}
