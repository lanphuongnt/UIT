#include <stdio.h>
#include <unistd.h>

int main() {
    printf("Sleeping for 10 seconds...\n");
    sleep(10);  // Ngủ 10 giây
    printf("Awake now!\n");
    return 0;
}

