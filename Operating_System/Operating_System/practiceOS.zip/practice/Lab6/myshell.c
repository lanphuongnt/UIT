#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>
#include <string.h>
#include <assert.h>
#include <stdlib.h>
#include <readline/readline.h>
#include <readline/history.h>
#include <fcntl.h>
#include <termios.h>

#define MAX_LINE 80 /* The maximum length command */
#define MAX_HISTORY_SIZE 50

char history[MAX_HISTORY_SIZE][MAX_LINE];
int history_count = 0;
int history_index = 0;

void solvePipeline(char *args[]);
void execute_command(char *args[]);
char **str_split(char *str, char delimiter);

int main(void) {
    int should_run = 1; /* flag to determine when to exit program */
 
    // Set up command history
    using_history();
    stifle_history(MAX_HISTORY_SIZE);

    puts("LMAO");
    // sleep(10);

    char **args; /* command line arguments */
    char *input;

    while (should_run) {
        puts("LMAOoo");

        // fflush(stdout);
        tcflush(STDIN_FILENO, TCIFLUSH);      
        input = readline("myshell> ");
        // fflush(stdout);
        // if (input == NULL) {
        //     fprintf(stderr, "Unable to read command\n");
        //     continue;
        // }
        fprintf(stderr, "Input: %s\n", input);
        puts("LMAKSMF");
        if (strlen(input) >= MAX_LINE) {
            fprintf(stderr, "Command is too long\n");
            continue;
        }
        // Add input to history
        if (input[0] != '\0') {
            add_history(input);
        }

        // Xóa kí tự xuống dòng
        input[strcspn(input, "\n")] = '\0';


        // Tách input thành các argument
        args = str_split(input, ' ');
        // Print args
        // printf("args: %s\n", args[0]);
        solvePipeline(args);
        puts("LMAO");
        free(input);
        free(args);
        //execute_command(args); 
            /**
                Do something
            */

        // free(input);
    }
    return 0;
}

void solvePipeline(char **args){
    int i = 0;
    int fd[2]; 
    // printf("args[%d]: %s\n", i, args[i]);
    // printf("%d", i);
    int final_pos = 0;
    int start_pos = 0;
    
    while (args[i] != NULL) {
        if (strcmp(args[i], "|") == 0){
            final_pos = i + 1;
            args[i] = NULL;
            // Create a pipe
            pipe(fd);
            // printf("args[%d]: %s\n", i, args[i]);
            pid_t pid = fork();
            if (pid < 0) {
                fprintf(stderr, "Fork Failed");
                return;
            } else if (pid == 0) {
                close(fd[0]);
                dup2(fd[1], STDOUT_FILENO);
                close(fd[1]);
                // fprintf(stderr, "Start pos: %d\n", start_pos);
                execute_command(&args[start_pos]);
                // pthread_exit(0);
                exit(0);
            } else {
                wait(NULL);
                start_pos = i + 1;
                // fprintf(stderr, "Wait child\n");
                close(fd[1]);
                dup2(fd[0], STDIN_FILENO);
                close(fd[0]);
                // sleep(1);
            }
        }
        i++;
    }
    fprintf(stderr, "\nFinal pos: %d\n", final_pos);
    if (final_pos != 0) {
        close(fd[0]);
        dup2(fd[1], STDOUT_FILENO);
        close(fd[1]);
        // final_pos = i;
    }
    // pipe(fd);
    execute_command(&args[final_pos]);
    fprintf(stderr, "Final pos: %d\n", final_pos);
}

void execute_command(char *args[]) {
    pid_t pid;
    pid = fork();
    if (pid < 0) {
        fprintf(stderr, "Fork Failed");
        return;
    } else if (pid == 0) {
        int i = 0;
        int fd_in, fd_out;
        // printf("args[%d]: %s\n", i, args[i]);
        while (args[i] != NULL) {
            // fprintf(stderr, "args[%d]: %s\n", i, args[i]);
            if (strcmp(args[i], ">") == 0){
                args[i] = NULL;
                fd_out = open(args[i + 1], O_WRONLY | O_CREAT | O_TRUNC, 0644);
                dup2(fd_out, STDOUT_FILENO);
                close(fd_out);
            }
            else {
                if (strcmp(args[i], "<") == 0) {
                    args[i] = NULL;
                    fd_in = open(args[i + 1], O_RDONLY);
                    dup2(fd_in, STDIN_FILENO);
                    close(fd_in);
                }
            }
            i++;
        }   
        // puts("LMAO");
        execvp(args[0], args);
    } else {
        wait(NULL);
    }
}

char **str_split(char *str, char delimiter) {
    char **result = malloc((MAX_LINE / 2 + 1) * sizeof(char *));
    char *token;
    int i = 0;

    token = strtok(str, &delimiter);
    while (token != NULL) {
        result[i++] = token;
        token = strtok(NULL, &delimiter);
    }
    result[i] = NULL;
    return result;
}
