#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>
#include <string.h>
#include <stdlib.h>
#include <fcntl.h>
#include <readline/readline.h>
#include <readline/history.h>
#include <termios.h>
#include <signal.h>
#include <stdbool.h>

#define MAX_LINE 80 /* The maximum length command */
#define MAX_HISTORY_SIZE 50

char history[MAX_HISTORY_SIZE][MAX_LINE];
int history_count = 0;
int history_index = 0;

void solvePipeline(char *args[]);
void execute_command(char *args[]);
char **str_split(char *str, char delimiter);
void signal_handler(int sig);
bool isQuit(char *args[]);
pid_t pid0;

int main(void)
{
    // Register the signal handler
    signal(SIGINT, signal_handler);
    int should_run = 1;
    // Array to store the arguments
    char **args; 
    // Input string
    char *input;

    while (should_run)
    {
        // Read the input
        input = readline("myshell> ");
        fflush(stdout);
        // If the input is null, print an error message and continue
        if (input == NULL)
        {
            fprintf(stderr, "Unable to read command\n");
            continue;
        }
        // If the input is too long, print an error message and continue
        if (strlen(input) >= MAX_LINE)
        {
            fprintf(stderr, "Command is too long\n");
            free(input);
            continue;
        }
        // If the input is not empty, add it to the history
        if (input[0] != '\0')
        {
            add_history(input);
        }
        // Split the input into arguments
        args = str_split(input, ' ');
        // If the command is quit, exit the shell
        if (isQuit(args))
        {
            printf("Exiting shell\n");
            return 0;
        }
        // Create a child process to execute the command
        pid0 = fork();
        if (pid0 == 0)
        {
            solvePipeline(args);
        }
        else
        {
            wait(NULL);
        }
        // Reset the pid
        pid0 = -1;
        // Free the memory
        free(input);
        free(args);
    }
    return 0;
}

// Function to solve the pipeline
void solvePipeline(char **args)
{

    int i = 0;
    int fd[2];
    int final_pos = 0;
    int start_pos = 0;

    while (args[i] != NULL)
    {
        if (strcmp(args[i], "|") == 0)
        {
            args[i] = NULL;
            final_pos = i + 1;
            pipe(fd);
            pid_t pid = fork();
            if (pid < 0)
            {
                fprintf(stderr, "Fork Failed");
                exit(EXIT_FAILURE);
            }
            else if (pid == 0)
            {
                // Child process
                close(fd[0]);
                dup2(fd[1], STDOUT_FILENO);
                close(fd[1]);
                // Execute the command of the pipeline
                execute_command(&args[start_pos]);
                exit(EXIT_SUCCESS);
            }
            else
            {
                // Parent process
                // Wait for the child process to finish
                wait(NULL);
                // Update the start position
                start_pos = i + 1;
                close(fd[1]);
                dup2(fd[0], STDIN_FILENO);
                close(fd[0]);
            }
        }
        i++;
    }
    // Execute the final command of the pipeline
    if (final_pos != 0)
    {
        close(fd[0]);
        dup2(fd[1], STDOUT_FILENO);
        close(fd[1]);
    }
    execute_command(&args[final_pos]);

    fflush(stdout);
    fflush(stdin);
    exit(EXIT_SUCCESS);
}

// Function to execute a command
void execute_command(char *args[])
{
    pid_t pid;
    pid = fork();
    if (pid < 0)
    {
        fprintf(stderr, "Fork Failed");
        return;
    }
    else if (pid == 0)
    {
        int i = 0;
        int fd_in, fd_out;
        while (args[i] != NULL)
        {
            // Check for redirection
            if (strcmp(args[i], ">") == 0)
            {
                args[i] = NULL;
                fd_out = open(args[i + 1], O_WRONLY | O_CREAT | O_TRUNC, 0644);
                dup2(fd_out, STDOUT_FILENO);
                close(fd_out);
            }
            else
            {
                if (strcmp(args[i], "<") == 0)
                {
                    args[i] = NULL;
                    fd_in = open(args[i + 1], O_RDONLY);
                    dup2(fd_in, STDIN_FILENO);
                    close(fd_in);
                }
            }
            i++;
        }
        execvp(args[0], args);
        exit(EXIT_FAILURE);
    }
    else
    {
        wait(NULL);
    }
}

// Function to split a string by a delimiter
char **str_split(char *str, char delimiter)
{
    char **result = malloc(sizeof(char *));
    char *token;
    int i = 0;

    token = strtok(str, &delimiter);
    while (token != NULL)
    {
        result = realloc(result, (i + 2) * sizeof(char *));
        if (result == NULL)
        {
            fprintf(stderr, "Memory allocation failed\n");
            exit(EXIT_FAILURE);
        }
        result[i++] = token;
        token = strtok(NULL, &delimiter);
    }
    result[i] = NULL;
    return result;
}


// Signal handler for SIGINT
// Kills the child process if it exists
void signal_handler(int sig)
{
    printf("\n");
    if (sig == SIGINT && pid0 > 0)
    {
        kill(pid0, SIGTERM);
    }
}

// Check if the command is quit
bool isQuit(char *args[])
{
    return strcmp(args[0], "quit") == 0;
}