#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>
// MSSV 
const int digits = 1168;
// Semaphore
sem_t sem;
int sells = 0, products = 0;

void* processA(void* arg){
	while (1){
		sem_wait(&sem);
		sells++;
		printf("sells = %d\n", sells);
	}
}

void* processB(void* arg){
	while(1){
		if (products < sells + digits){
			products++;
			printf("products = %d\n", products);
			sem_post(&sem);
		}
	}
}

int main(){
	pthread_t pA, pB;
	sem_init(&sem, 0, 0);
	pthread_create(&pA, NULL, &processA, NULL);
	pthread_create(&pB, NULL, &processB, NULL);
	
	pthread_join(pA, NULL);
	pthread_join(pB, NULL);
	sem_destroy(&sem);
	return 0;
}

