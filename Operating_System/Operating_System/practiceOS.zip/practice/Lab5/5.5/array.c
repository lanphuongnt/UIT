#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

#define SIZE 10
sem_t sem;


// Khai bao mang a chua 10 phan tu
int a[SIZE];
// So phan tu hien tai
int current_size = 0; 

void* processA(void* arg){
	while (1){
        
        if (current_size < SIZE){
            a[current_size++] = rand() % 101;
        }
        printf("Count = %d\n", current_size);
	}
}

void* processB(void* arg){
	while(1){
		if (current_size > 0){
            a[--current_size] = 0;
            printf("Remove one element of a\n");
        }
        else {
            printf("Nothing in array a\n");
        }
	}
}

int main(){
    srand(time(NULL));
    memset(a, 0, sizeof(a));
	pthread_t pA, pB;
	sem_init(&sem, 0, 0);
	pthread_create(&pA, NULL, &processA, NULL);
	pthread_create(&pB, NULL, &processB, NULL);
	
	pthread_join(pA, NULL);
	pthread_join(pB, NULL);
	sem_destroy(&sem);
	return 0;
}

