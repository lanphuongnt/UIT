#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

#define SIZE 10
sem_t sem;


// Khai bao mang a chua 10 phan tu
int a[SIZE];
// So phan tu hien tai
int current_size = 0; 

void* processA(void* arg){
	while (1){
        sem_wait(&sem);
        if (current_size < SIZE){
            int ran = 0;
            while(!ran){
                ran = rand() % 101;
            }
            a[current_size++] = ran;
            printf("Thread A: Add one element -> Count = %d\n", current_size);
        }
        sem_post(&sem);
    }
}

void* processB(void* arg){
	while(1){
        sem_wait(&sem);
		if (current_size > 0){
            a[--current_size] = 0;
            printf("Thread B: Remove one element of a -> Count = %d\n", current_size);
        }
        else {
            printf("Thread B: Nothing in array a\n");
        }
        sem_post(&sem);
	}
}

int main(){
    srand(time(NULL));
    memset(a, 0, sizeof(a));
	pthread_t pA, pB;
	sem_init(&sem, 0, 1);
	pthread_create(&pA, NULL, &processA, NULL);
	pthread_create(&pB, NULL, &processB, NULL);
	
	pthread_join(pA, NULL);
	pthread_join(pB, NULL);
	sem_destroy(&sem);
	return 0;
}

