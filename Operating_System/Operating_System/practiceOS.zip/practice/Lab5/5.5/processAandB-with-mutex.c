#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

#define SIZE 10


int x = 0;
pthread_mutex_t lock;

void* processA(void* arg){
    while(1){
        pthread_mutex_lock(&lock);
        x = x + 1;
        if (x == 20)
            x = 0;
        printf("Thread A: %d\n", x);
        pthread_mutex_unlock(&lock);
    }
}

void* processB(void* arg){
	while(1){
        pthread_mutex_lock(&lock);
        x = x + 1;
        if (x == 20)
            x = 0;
        printf("Thread B: %d\n", x);
        pthread_mutex_unlock(&lock);
    }
}

int main(){
	pthread_t pA, pB;
    pthread_mutex_init(&lock, NULL);
	pthread_create(&pA, NULL, &processA, NULL);
	pthread_create(&pB, NULL, &processB, NULL);
	
	pthread_join(pA, NULL);
	pthread_join(pB, NULL);
	return 0;
}

