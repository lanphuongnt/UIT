#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

pthread_t thread_A, thread_B, thread_C, thread_D, thread_E, thread_F, thread_G;
int x1, x2, x3, x4, x5, x6;
int w, v, y, z, ans;
sem_t sem_v, sem_y, sem_z, sem_w;


void* thread_func_A(void* arg){
    w = x1 * x2;
    printf("Thread A | w = x1 * x2 = %d\n", w);
    sem_post(&sem_w);
    sem_post(&sem_w);
}

void* thread_func_B(void* arg){
    v = x3 * x4;
    printf("Thread B | v = x3 * x4 = %d\n", v);
    sem_post(&sem_v);
    sem_post(&sem_v);
}

void* thread_func_C(void* arg){
    sem_wait(&sem_v);
    y = v * x5;
    printf("Thread C | y = v * x5 = %d\n", y);
    sem_post(&sem_y);
}

void* thread_func_D(void* arg){
    sem_wait(&sem_v);
    z = v * x6;
    printf("Thread D | z = v * x6 = %d\n", z);
    sem_post(&sem_z);
}

void* thread_func_E(void* arg){
    sem_wait(&sem_w);
    sem_wait(&sem_y);
    y = w * y;
    printf("Thread E | y = w * y = %d\n", y);
    sem_post(&sem_y);
}

void* thread_func_F(void* arg){
    sem_wait(&sem_w);
    sem_wait(&sem_z);
    z = w * z;
    printf("Thread F | z = w * z = %d\n", z);
    sem_post(&sem_z);
}


void* thread_func_G(void* arg){
    ans = y + z;
    printf("Thread G | ans = y + z = %d\n", ans);
}

int main(){
    int result;
    x1 = x2 = x3 = x4 = x5 = x6 = 6;
    printf("Please enter 6 integers:\n");
    result = scanf("%d%d%d%d%d%d", &x1, &x2, &x3, &x4, &x5, &x6);

    if (result == 6) {
        printf("You entered: %d %d %d %d %d %d\n", x1, x2, x3, x4, x5, x6);
    } else {
        printf("Error: Please enter exactly 6 integers.\n");
        exit(0);
    }

    sem_init(&sem_w, 0, 0);
    sem_init(&sem_v, 0, 0);
    sem_init(&sem_y, 0, 0);
    sem_init(&sem_z, 0, 0);


	pthread_create(&thread_A, NULL, &thread_func_A, NULL);
	pthread_create(&thread_B, NULL, &thread_func_B, NULL);
	pthread_create(&thread_C, NULL, &thread_func_C, NULL);
	pthread_create(&thread_D, NULL, &thread_func_D, NULL);
	pthread_create(&thread_E, NULL, &thread_func_E, NULL);
	pthread_create(&thread_F, NULL, &thread_func_F, NULL);
	
    pthread_join(thread_A, NULL);
    pthread_join(thread_B, NULL);
    pthread_join(thread_C, NULL);
    pthread_join(thread_D, NULL);
    pthread_join(thread_E, NULL);
    pthread_join(thread_F, NULL);

	pthread_create(&thread_G, NULL, &thread_func_G, NULL);
    pthread_join(thread_G, NULL);

    pthread_exit(NULL);
	return 0;
}

